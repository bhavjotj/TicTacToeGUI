 
/**
 * TicTacToe is a game for two players who take turns marking the
 * spaces in a 3×3 grid wiht X or O.The player who succeeds in placing 
 * three of their letters in a horizontal, vertical, or diagonal row 
 * is the winner!
 *
 * @author (Bhavjot Jhutty)
 * @version (December 17, 2019)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
//imports the libraries
public class ttt extends JPanel implements ActionListener
{
    JLabel move;
    //this variable is tells you who's move it is
    JLabel winner;
    //this variable tells you who won the round (player 1 or 2)
    int turn = 1;
    //this variable initalizes who's turn it is (player 1 or 2)
    boolean win = false;
    //sets win variable
    char SPOTS[][] = new char[3][3];
    //makes grid
    CardLayout myCardLayout =  new CardLayout();
    //this is the layout of my cards/screens
    JButton spots[][] = new JButton[3][3];
    //makes grid
    JButton reset;
    //this button is used to reset the board
    JButton resetsc;
    //this button is used to reset the score
    JLabel scores;
    //this tells you how many points each player has (scoreboard)
    int points1 = 0;
    //amount of points player 1 has
    int points2 = 0;
    //amount of points player 2 has
    JButton playagain;
    //play again button

    //these variables are used throughout the program 
    //global variables

    public static void main (String args [])
    {
        ttt content = new ttt();
        JFrame window = new JFrame ("TicTacToe");
        //creates JFrame window
        window.setSize (500,500);
        //sets size of JFrame
        window.setLocation (100,100);
        //sets location of JFrame
        window.setResizable(false);
        //makes it non-resizeable
        window.setContentPane(content);
        window.setVisible(true);
    }//eof main

    public ttt()
    {
        setLayout (myCardLayout);
        //the layout of the cards
        mainscreen();
        //first screen (main menu)
        rulesscreen();
        //second screen (instructions)
        option();
        //third screen (options)
        score();
        //fourth screen (actual game)
        win();
        //fifth screen (winning screen)

    }//eof ttt

    public void mainscreen()
    //the main screen method
    {
        JLabel pic = new JLabel(createImageIcon("tttpic6.png"));
        pic.setBounds(150,265,200,200);
        //adds an image and is located using set bounds

        JPanel mainsc = new JPanel();
        mainsc.setBackground(Color.orange);
        mainsc.setLayout(new BorderLayout());
        // creates the JPanel, layout and displays colour of the panel

        JLabel title = new JLabel("  TicTacToe");
        //name of JLabel is created
        title.setFont(new Font("SEYMOURONE",Font.BOLD,75));
        //font for JLabel is created
        title.setForeground(Color.black);
        //colour for JLabel is created
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        // JLabel is centralized
        mainsc.add(title,BorderLayout.NORTH);
        //JLabel is placed in the north of the panel

        JPanel centerbuts = new JPanel();
        // a new panel is made so both buttons can be placed in the center
        centerbuts.setBackground(Color.orange);
        centerbuts.setLayout(new BoxLayout(centerbuts,BoxLayout.PAGE_AXIS));
        //colour is set and the layout is created

        JLabel space3 = new JLabel ("  ");
        centerbuts.add(space3);
        //used to create some space between the title and the buttons

        JLabel space = new JLabel ("  ");
        centerbuts.add(space);
        //more space because it is too close

        JButton play = new JButton("        Play        ");
        play.setFont(new Font("SEYMOURONE",Font.BOLD,35));
        play.setForeground(Color.black);
        play.setActionCommand("option");
        play.addActionListener(this);
        play.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerbuts.add(play);
        //play button is created and added in the button panel, 
        //it leads you to options screen
        //the font is also set and JLabel is in the center

        JLabel space2 = new JLabel ("  ");
        centerbuts.add(space2);
        //used to create some space between both buttons

        JButton instru = new JButton("Instructions (Rules)");
        instru.setFont(new Font("SEYMOURONE",Font.BOLD,35));
        instru.setForeground(Color.black);
        instru.setActionCommand("rules");
        instru.addActionListener(this);
        instru.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerbuts.add(instru);
        //play button is created and added in the button panel, 
        //it leads you to rules screen
        //the font is also set and JLabel is in the center

        JLabel x = new JLabel("X");
        x.setFont(new Font("SEYMOURONE",Font.BOLD,90));
        x.setForeground(Color.black);
        mainsc.add(x,BorderLayout.WEST);
        // this JLabel is meant for design
        //font and colour is set and it is located in the west side of the panel

        JLabel o = new JLabel("O");
        o.setFont(new Font("SEYMOURONE",Font.BOLD,90));
        o.setForeground(Color.black);
        mainsc.add(o,BorderLayout.EAST);
        // this JLabel is meant for design
        //font and colour is set and it is located in the east side of the panel

        mainsc.add(pic);
        //adds the image
        mainsc.add(centerbuts, BorderLayout.CENTER);
        //this adds the buttons panel into the main panel

        add("main",mainsc);
        //adds the screen
    }//eof main screen

    public void rulesscreen()
    //the rules screen method
    {
        JPanel rulesc = new JPanel();
        rulesc.setBackground(Color.orange);
        rulesc.setLayout(new BoxLayout(rulesc, BoxLayout.Y_AXIS));
        //I have set the panel, panel colour and the layout 

        Font headerfont = new Font("SEYMOURONE", Font.BOLD,40);
        Font txtfont = new Font ("SEYMOURONE", Font.PLAIN,25);
        //makes it easier to utilize the fonts for the next JLabels

        JLabel HTP = new JLabel ("How To Play:");
        HTP.setFont(headerfont);
        HTP.setAlignmentX(Component.CENTER_ALIGNMENT);
        //shows the header for how to play

        JLabel htp1 = new JLabel("- Using the mouse, click on where");
        htp1.setFont(txtfont);
        htp1.setAlignmentX(Component.CENTER_ALIGNMENT);
        //explains how to play

        JLabel htp2 = new JLabel ("you want to place your letter");
        htp2.setFont(txtfont);
        htp2.setAlignmentX(Component.CENTER_ALIGNMENT);
        //explains how to play

        JLabel rules = new JLabel ("Rules:");
        rules.setFont(headerfont);
        rules.setAlignmentX(Component.CENTER_ALIGNMENT);
        //shows the header for the rules

        JLabel rules1 = new JLabel ("-Players take turn putting their");
        rules1.setFont(txtfont);
        rules1.setAlignmentX(Component.CENTER_ALIGNMENT);
        //explains the rules

        JLabel rules2 = new JLabel (" letters in empty squares");
        rules2.setFont(txtfont);
        rules2.setAlignmentX(Component.CENTER_ALIGNMENT);
        //explains the rules

        JLabel rules3 = new JLabel ("- 1 Player is X, the other is O");
        rules3.setFont(txtfont);
        rules3.setAlignmentX(Component.CENTER_ALIGNMENT);
        //explains the rules

        JLabel rules4 = new JLabel ("- First to get 3 in a row wins");
        rules4.setFont(txtfont);
        rules4.setAlignmentX(Component.CENTER_ALIGNMENT);
        //explains the rules

        JLabel rules5 = new JLabel ("(vertically, horizontally, diagonally)");
        rules5.setFont(txtfont);
        rules5.setAlignmentX(Component.CENTER_ALIGNMENT);
        //explains the rules

        //all instructions are centralized used setAlignmentX

        JLabel space = new JLabel ("  ");
        JLabel space2 = new JLabel ("  ");
        JLabel space3 = new JLabel ("  ");
        //these are spaces needed in the panel because it was clustered

        JButton cont = new JButton ("Continue");
        cont.setActionCommand("option");
        cont.addActionListener(this);
        cont.setFont(new Font("SEYMOURONE", Font.BOLD,55));
        cont.setAlignmentX(Component.CENTER_ALIGNMENT);
        //this button allows you to continue to the options screen
        //it is set for you so you can play 

        rulesc.add(HTP);rulesc.add(htp1);rulesc.add(htp2);
        rulesc.add(space2);rulesc.add(rules);rulesc.add(rules1);
        rulesc.add(rules2);rulesc.add(rules3);rulesc.add(rules4);
        rulesc.add(rules5);rulesc.add(space);rulesc.add(space3);
        rulesc.add(cont);
        add("rules",rulesc);
        //adds every label/button in order
    }//eof rulesscreen

    public void option()
    //the options method
    {
        JLabel pic = new JLabel(createImageIcon("tttpic6.png"));
        pic.setBounds(150,265,200,200);
        //adds the image 

        JPanel optsc = new JPanel();
        optsc.setBackground(Color.orange);
        optsc.setLayout(new BorderLayout());
        //this sets the panel, panel colour and layout for the panel

        JLabel title1 = new JLabel("  TicTacToe");
        title1.setFont(new Font("SEYMOURONE",Font.BOLD,75));
        title1.setAlignmentX(Component.CENTER_ALIGNMENT);

        //sets the title, title font, and sets location in the north  

        JPanel options = new JPanel();
        options.setBackground(Color.orange);
        options.setLayout(new BoxLayout(options,BoxLayout.Y_AXIS));
        //another panel is created to place the buttons in a different layout

        JLabel space = new JLabel ("  ");
        JLabel space1 = new JLabel ("  ");
        JLabel space2 = new JLabel ("  ");
        JLabel space3 = new JLabel ("  ");
        //these spaces are needed for organization

        JButton score = new JButton("Scoreboard Mode");
        score.setFont(new Font("SEYMOURONE",Font.BOLD,35));
        score.setActionCommand("score");
        score.addActionListener(this);
        //this button is an option if you want to play ttt with a scoreboard
        //font is created and when clicked, 
        //it will lead to the ttt screen with a scoreboard

        JLabel x = new JLabel("X");
        x.setFont(new Font("SEYMOURONE",Font.BOLD,90));
        // this JLabel is meant for design
        //font is set and it is located in the west side

        JLabel o = new JLabel("O");
        o.setFont(new Font("SEYMOURONE",Font.BOLD,90));
        // this JLabel is meant for design
        //font is set and it is located in the east side 

        optsc.add(title1,BorderLayout.NORTH);
        options.add(space);
        options.add(space1);
        options.add(space2);
        options.add(space3);
        options.add(score);
        optsc.add(x,BorderLayout.WEST);
        optsc.add(o,BorderLayout.EAST);
        optsc.add(pic);
        optsc.add(options, BorderLayout.CENTER);
        //everything is added onto the options panel
        add("option",optsc);
        //add the option screen

    }//eof option

    public void score()
    //this is the ttt game with a scoreboard
    {

        JPanel grid = new JPanel();
        grid.setLayout(new GridLayout(3,3));
        //the panel and layout of the panel have been set
        for (int i = 0; i<3; i++)
        {
            for (int j = 0; j<3; j++)
            {
                spots[i][j] = new JButton();
                //sets buttons in the 3x3
                spots[i][j].addActionListener(this);
                spots[i][j].setActionCommand(""+((i*10)+j));
                grid.add(spots[i][j]);
                //adds the spots in the array
            }
        }
        //array used to create a 3x3 board for tictactoe

        JPanel scorescreen = new JPanel();
        scorescreen.setBackground(Color.orange);
        scorescreen.setLayout(new BorderLayout());
        //another panel is created and borderlayout is used

        move = new JLabel ("      PLAYER 1'S TURN");
        move.setFont(new Font("SEYMOURONE",Font.BOLD,40));
        scorescreen.add(move,BorderLayout.NORTH);
        //the JLabel has already been initialized
        //tells you who's move it is
        //font and location is set

        scores = new JLabel("   Score:  Player 1 = 0    Player 2 = 0");
        scores.setFont(new Font("SEYMOURONE",Font.BOLD,25));
        scorescreen.add(scores,BorderLayout.SOUTH);
        //has already been initialized as global
        //it is a scoreboard
        //font and location is set

        JPanel resetbut = new JPanel();
        resetbut.setBackground(Color.orange);
        resetbut.setLayout(new BoxLayout(resetbut,BoxLayout.PAGE_AXIS));
        //one more layout is used for 2 reset buttons

        reset = new JButton(" Reset Board ");
        reset.setFont(new Font("SEYMOURONE",Font.BOLD,25));
        reset.setActionCommand("reset");
        reset.addActionListener(this);
        reset.setAlignmentX(Component.CENTER_ALIGNMENT);
        resetbut.add(reset);
        //the JButton is set and added
        //the button clears the board (removes everything)
        //font is set

        resetsc= new JButton(" Reset Score ");
        resetsc.setFont(new Font("SEYMOURONE",Font.BOLD,25));
        resetsc.setActionCommand("resetsc");
        resetsc.addActionListener(this);
        resetsc.setAlignmentX(Component.CENTER_ALIGNMENT);
        resetbut.add(resetsc);
        //the JButton is set and added
        //the button clears the score (removes points)
        //font is set

        scorescreen.add(resetbut,BorderLayout.EAST);
        //this adds the reset buttons to the east side of screen

        scorescreen.add (grid, BorderLayout.CENTER);
        //adds the 3x3 grid in the center
        add("score",scorescreen);
        //add the score screen

    }//eof score

    public void win()
    //the win screen
    {

        JPanel winsc = new JPanel();
        winsc.setBackground(Color.orange);
        winsc.setLayout(new BorderLayout());
        //the win panel and layout has been set 

        winner = new JLabel ("  Player" +turn+" Wins!");
        winner.setFont(new Font("SEYMOURONE", Font.BOLD,60));
        //winner has been initialized as global
        //tells you who won
        //font is set

        JLabel gif = new JLabel(createImageIcon("wincopy2.gif"));
        //a funny little gif is created

        playagain = new JButton ("Play Again");
        playagain.setFont(new Font("SEYMOURONE", Font.BOLD,30));
        playagain.setActionCommand("reset");
        playagain.addActionListener(this);
        playagain.setBounds(20,400,230,50);
        winsc.add(playagain);
        //a button is created to play the same game again
        //located below the gif
        //font is set

        JButton menu = new JButton (" Main Menu ");
        menu.setFont(new Font("SEYMOURONE", Font.BOLD,30));
        menu.setActionCommand("main");
        menu.addActionListener(this);
        menu.setBounds(255,400,230,50);
        winsc.add(menu);
        //a button that takes you back to the main menu
        //located below the gif and to the right of the playagain button
        //font is set

        winsc.add(winner,BorderLayout.NORTH);
        winsc.add(gif,BorderLayout.CENTER);
        //both the title and gif are added at the end and positioned as stated
        add("win", winsc);
        //adds win screen
    }//eof win

    public void actionPerformed (ActionEvent e)
    //the actionPerformed method
    {

        if (e.getActionCommand ().equals ("main"))
        {
            for (int i = 0; i<3; i++)
            {
                for (int j = 0; j<3; j++)
                {
                    spots[i][j].setText (" ");
                    //changes the image to have no letter
                    SPOTS[i][j] = ' ';
                    //changes the value to nothing so win isn't true
                }
            }

            for (int i = 0; i<3; i++)
            {
                for (int j = 0; j<3; j++)
                {
                    spots[i][j].setText("");
                    spots[i][j].setEnabled(true);
                    SPOTS[i][j] = ' ';
                }
            }
            //resets the rows 
            win = false;
            //changes the win to false
            myCardLayout.show (this, "main");
            //shows main screen
        }

        else if (e.getActionCommand ().equals ("rules"))
            myCardLayout.show (this, "rules");
        else if (e.getActionCommand ().equals ("option"))
            myCardLayout.show (this, "option");
        else if (e.getActionCommand ().equals ("score"))
            myCardLayout.show (this, "score");
        else if (e.getActionCommand ().equals ("win"))
            myCardLayout.show (this, "win");
        // basically sets the cardlayout 

        if (e.getActionCommand ().equals ("menu"))
        //if main menu is clicked it goes to main screen
        {
            myCardLayout.show(this,"main");
        }

        if (e.getActionCommand().equals("resetsc"))
        {
            //if reset score button gets clicked the scores become 0
            points1 = 0;
            //player 1 gets 0 points
            points2 = 0;
            //player 2 gets 0 points
            scores.setText("  Score:  Player 1 = "+points1+"  Player 2 = " +points2);
            // the scoreboard shows that both players have 0 points
        }
        if(e.getActionCommand().equals("reset"))
        // if reset board button gets clicked the board gets cleared
        {
            for (int i = 0; i<3; i++)
            {
                for (int j = 0; j<3; j++)
                {
                    spots[i][j].setText (" ");
                    //changes the image to have no letters
                    SPOTS[i][j] = ' ';
                    //changes the value to nothing so win isn's true
                }
            }

            for (int i = 0; i<3; i++)
            {
                for (int j = 0; j<3; j++)
                {
                    spots[i][j].setText("");
                    spots[i][j].setEnabled(true);
                    SPOTS[i][j] = ' ';
                }
            }
            //resets the rows 
            win = false;
            //changes the win to false
            myCardLayout.show (this, "score");

            //shows the score screen
        }

        if((!e.getActionCommand ().equals ("win"))&&(!e.getActionCommand ().equals ("rules"))
        &&!(e.getActionCommand ().equals ("option"))&&!(e.getActionCommand ().equals ("score"))
        &&!(e.getActionCommand ().equals ("reset"))&&!(e.getActionCommand ().equals ("play"))
        &&!(e.getActionCommand ().equals ("resetsc"))
        &&!(e.getActionCommand().equals ("main")))
        {
            int nn = Integer.parseInt (e.getActionCommand ());
            int  x = nn / 10;
            int  y = nn % 10;
            if(turn == 1 && win == false)
            {
                spots[x][y].setText("X");
                spots[x][y].setEnabled(false);
                SPOTS[x][y] = 'X';
                //allows you to place X

            }
            else if(turn == 2 && win == false)
            {
                spots[x][y].setText("O");
                spots[x][y].setEnabled(false);
                SPOTS[x][y] = 'O';

                //allows you to place O
            }
        }

        if((SPOTS[0][0] == SPOTS[0][1]) && (SPOTS[0][1] == SPOTS[0][2])
        &&(SPOTS[0][0] == 'X'|| SPOTS[0][0] == 'O'))
        {
            win = true;
            //win is true if either X or O is in those positions

        }
        else if ((SPOTS[1][0] == SPOTS[1][1]) && (SPOTS[1][1] == SPOTS[1][2])
        &&(SPOTS[1][1] == 'X' || SPOTS[1][1] == 'O'))
        {
            win = true;
            //win is true if either X or O is in those positions

        }
        else if ((SPOTS[2][0] == SPOTS[2][1]) && (SPOTS[2][1] == SPOTS[2][2])
        &&(SPOTS[2][2] == 'X'|| SPOTS[2][2] == 'O'))
        {
            win = true;
            //win is true if either X or O is in those positions

        }
        else if ((SPOTS[2][0] == SPOTS[1][0]) && (SPOTS[0][0] == SPOTS[2][0])
        &&(SPOTS[0][0] == 'X' || SPOTS[0][0] == 'O'))
        {
            win = true;
            //win is true if either X or O is in those positions

        }
        else if ((SPOTS[2][1] == SPOTS[1][1]) && (SPOTS[1][1] == SPOTS[0][1])
        &&(SPOTS[1][1] == 'X'|| SPOTS[1][1] == 'O'))
        {
            win = true;
            //win is true if either X or O is in those positions

        }
        else if ((SPOTS[1][2] == SPOTS[0][2]) && (SPOTS[2][2] == SPOTS[1][2])
        &&(SPOTS[2][2] == 'X'|| SPOTS[2][2] == 'O'))
        {
            win = true;
            //win is true if either X or O is in those positions

        }
        else if ((SPOTS[0][0] == SPOTS[1][1]) && (SPOTS[2][2] == SPOTS[1][1])
        &&(SPOTS[1][1] == 'X'|| SPOTS[1][1] == 'O'))
        {
            win = true;
            //win is true if either X or O is in those positions

        }
        else if ((SPOTS[2][0] == SPOTS[1][1]) && (SPOTS[0][2] == SPOTS[1][1])
        &&(SPOTS[1][1] == 'X' || SPOTS[1][1] == 'O'))
        {
            win = true;
            //win is true if either X or O is in those positions

        }

        if (win == true)
        {
            myCardLayout.show(this,"win");
            //if the win is true, it displays the win screen
        }

        if (win == true && turn == 1)
        //if the win is true and player 1 wins, they get a point
        {
            points1++;
            //adds a point for player 1
            scores.setText("  Score:  Player 1 = "+points1+"  Player 2 = " +points2);
            //displays the updated scoreboard
        }
        else if (win == true && turn == 2)
        //if the win is true and player 2 wins, they get a point
        {
            points2++;
            //adds a point for player 2
            scores.setText("  Score:  Player 1 = "+points1+"  Player 2 = " +points2);
            //displays the updated scoreboard
        }

        if(turn == 1)
        {
            turn++;
            move.setText("      PLAYER 2'S TURN");
            //if player 1 places a letter, it will show that it is player 2's turn
            winner.setText("  Player 1 Wins!");
            //if player 1 gets 3 in a row, it will show that player 1 wins
        }
        else if(turn == 2)
        {
            turn--;
            move.setText("      PLAYER 1'S TURN");
            //if player 2 places a letter, it will show that it is player 1's turn
            winner.setText("  Player 2 Wins!");
            //if player 2 gets 3 in a row, it will show that player 2 wins
        }

    }//eof actionPerformed

    protected static ImageIcon createImageIcon (String path)
    //used to display the gif and images
    {
        java.net.URL imgURL = ttt.class.getResource(path);
        if (imgURL != null){
            return new ImageIcon (imgURL);
        } else {
            System.err.println( "Couldn't find file: " + path);
            return null;
        }
    }//end

}//eof of ttt

